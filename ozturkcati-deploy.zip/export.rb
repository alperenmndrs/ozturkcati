require "fileutils"
require "json"
require "open-uri"
require "uri"

LOCAL_ORIGIN = "http://ztrk-at.local"
LOCAL_HOST = "ztrk-at.local"
BASE_PATH = "/ozturkcati"
OUTPUT = File.expand_path(__dir__)
FALLBACK_ROUTES = ["/", "/hizmetler/", "/sistemler/", "/projeler/", "/kurumsal/", "/iletisim/"]

def fetch(url)
  URI.open(url, read_timeout: 30) { |response| response.read }
end

def rewrite_paths(content)
  content = content.gsub(LOCAL_ORIGIN, BASE_PATH)
  content.gsub!(/<link\b(?=[^>]*\brel=["']alternate["'])[^>]*>/i, "")
  content.gsub!(/<script\b[^>]*wp-emoji-release\.min\.js[^>]*>\s*<\/script>/i, "")
  content.gsub!(/<script\b[^>]*id=["']wp-emoji-settings["'][^>]*>.*?<\/script>/im, "")
  content.gsub!(/<script\b(?=[^>]*\btype=["']module["'])[^>]*>.*?wpEmojiSettingsSupports.*?<\/script>/im, "")
  unless content.match?(/<meta\s+charset=/i)
    content.sub!(/<head\b[^>]*>/i) { |head| "#{head}<meta charset=\"utf-8\">" }
  end
  base_segment = Regexp.escape(BASE_PATH.sub(%r{\A/}, ""))
  base_boundary = "(?:/|[\"'?#\\s]|$)"
  content.gsub!(/((?:href|src|poster|action|data-[\w-]+)\s*=\s*["'])\/(?!\/|#{base_segment}#{base_boundary})/i) { "#{$1}#{BASE_PATH}/" }
  content.gsub!(/(srcset\s*=\s*["'])(.*?)(["'])/i) do
    prefix = $1
    delimiter = $3
    entries = $2.split(",").map do |entry|
      entry.sub(%r{\A(\s*)/(?!/|#{base_segment}#{base_boundary})}, "\\1#{BASE_PATH}/")
    end
    "#{prefix}#{entries.join(",")}#{delimiter}"
  end
  content.gsub!(/url\(\s*(["']?)\/(?!\/|#{base_segment}#{base_boundary})/i) { "url(#{$1}#{BASE_PATH}/" }
  content
end

def local_url(value, base_url)
  uri = URI.join(base_url, value.strip)
  return unless uri.host == LOCAL_HOST
  return if uri.path.empty? || uri.path == "/"
  return if uri.path.end_with?("/")
  return if uri.path.match?(%r{(?:\A|/)(?:wp-admin|wp-json|xmlrpc\.php|comments|feed)(?:/|$)})

  uri
rescue URI::InvalidURIError
  nil
end

def referenced_urls(content, base_url)
  urls = []
  content.scan(/\b(?:src|href|poster|action|data-[\w-]+)\s*=\s*["']([^"']+)["']/i) do |match|
    urls << match.first
  end
  content.scan(/\bsrcset\s*=\s*["']([^"']+)["']/i) do |match|
    urls.concat(match.first.split(",").map { |entry| entry.strip.split.first })
  end
  content.scan(/url\(\s*(["']?)(.*?)\1\s*\)/i) do |match|
    urls << match.last
  end
  urls.map { |url| local_url(url, base_url) }.compact
end

def output_path(path)
  File.join(OUTPUT, path.sub(%r{\A/}, ""))
end

routes = FALLBACK_ROUTES.dup
begin
  pages = JSON.parse(fetch("#{LOCAL_ORIGIN}/wp-json/wp/v2/pages?per_page=100&_fields=link"))
  routes.concat(pages.map { |page| URI(page.fetch("link")).path })
rescue StandardError => error
  warn "Could not list WordPress pages; exporting the main navigation only (#{error.class})."
end
routes.uniq!

downloaded = {}
pending_assets = []
routes.each do |route|
  page_url = "#{LOCAL_ORIGIN}#{route}"
  html = fetch(page_url)
  pending_assets.concat(referenced_urls(html, page_url))
  relative_page = route == "/" ? "index.html" : File.join(route.sub(%r{\A/}, ""), "index.html")
  destination = File.join(OUTPUT, relative_page)
  FileUtils.mkdir_p(File.dirname(destination))
  File.write(destination, rewrite_paths(html))
end

until pending_assets.empty?
  asset_uri = pending_assets.shift
  relative_path = asset_uri.path
  next if downloaded[relative_path]
  downloaded[relative_path] = true

  begin
    content = fetch(asset_uri.to_s)
    if relative_path.end_with?(".css")
      pending_assets.concat(referenced_urls(content, asset_uri.to_s))
      content = rewrite_paths(content)
    end
    destination = output_path(relative_path)
    FileUtils.mkdir_p(File.dirname(destination))
    File.binwrite(destination, content)
  rescue StandardError => error
    warn "Skipped #{relative_path} (#{error.class})."
  end
end

File.write(File.join(OUTPUT, ".nojekyll"), "")
puts "Exported #{routes.length} pages and #{downloaded.length} local assets to #{OUTPUT}."